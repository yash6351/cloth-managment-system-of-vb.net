﻿Partial Class DatabaseDataSet
End Class

Namespace DatabaseDataSetTableAdapters

    Partial Public Class staffTableAdapter
    End Class
End Namespace
