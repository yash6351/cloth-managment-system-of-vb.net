﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Mdimain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewEmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditEmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteEmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewEmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewCategoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewStockListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransectionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StcokReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PurchaseReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmployeeReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveUserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowUsersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplicatiionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmployeeToolStripMenuItem, Me.MasterDetailsToolStripMenuItem, Me.TransectionsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.UserToolStripMenuItem, Me.ApplicatiionToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(985, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EmployeeToolStripMenuItem
        '
        Me.EmployeeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewEmployeeToolStripMenuItem, Me.EditEmployeeToolStripMenuItem, Me.DeleteEmployeeToolStripMenuItem, Me.ViewEmployeeToolStripMenuItem})
        Me.EmployeeToolStripMenuItem.Name = "EmployeeToolStripMenuItem"
        Me.EmployeeToolStripMenuItem.Size = New System.Drawing.Size(80, 24)
        Me.EmployeeToolStripMenuItem.Text = "Our Staff"
        '
        'AddNewEmployeeToolStripMenuItem
        '
        Me.AddNewEmployeeToolStripMenuItem.Name = "AddNewEmployeeToolStripMenuItem"
        Me.AddNewEmployeeToolStripMenuItem.Size = New System.Drawing.Size(189, 24)
        Me.AddNewEmployeeToolStripMenuItem.Text = "Add Staff"
        '
        'EditEmployeeToolStripMenuItem
        '
        Me.EditEmployeeToolStripMenuItem.Name = "EditEmployeeToolStripMenuItem"
        Me.EditEmployeeToolStripMenuItem.Size = New System.Drawing.Size(189, 24)
        Me.EditEmployeeToolStripMenuItem.Text = "Update Staff"
        '
        'DeleteEmployeeToolStripMenuItem
        '
        Me.DeleteEmployeeToolStripMenuItem.Name = "DeleteEmployeeToolStripMenuItem"
        Me.DeleteEmployeeToolStripMenuItem.Size = New System.Drawing.Size(189, 24)
        Me.DeleteEmployeeToolStripMenuItem.Text = "Delete Staff"
        '
        'ViewEmployeeToolStripMenuItem
        '
        Me.ViewEmployeeToolStripMenuItem.Name = "ViewEmployeeToolStripMenuItem"
        Me.ViewEmployeeToolStripMenuItem.Size = New System.Drawing.Size(189, 24)
        Me.ViewEmployeeToolStripMenuItem.Text = "ViewAll Staff List"
        '
        'MasterDetailsToolStripMenuItem
        '
        Me.MasterDetailsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewCategoryToolStripMenuItem, Me.AddNewStockToolStripMenuItem, Me.ViewStockListToolStripMenuItem})
        Me.MasterDetailsToolStripMenuItem.Name = "MasterDetailsToolStripMenuItem"
        Me.MasterDetailsToolStripMenuItem.Size = New System.Drawing.Size(105, 24)
        Me.MasterDetailsToolStripMenuItem.Text = "Basic Details"
        '
        'AddNewCategoryToolStripMenuItem
        '
        Me.AddNewCategoryToolStripMenuItem.Name = "AddNewCategoryToolStripMenuItem"
        Me.AddNewCategoryToolStripMenuItem.Size = New System.Drawing.Size(214, 24)
        Me.AddNewCategoryToolStripMenuItem.Text = "Add New Cloth Type"
        '
        'AddNewStockToolStripMenuItem
        '
        Me.AddNewStockToolStripMenuItem.Name = "AddNewStockToolStripMenuItem"
        Me.AddNewStockToolStripMenuItem.Size = New System.Drawing.Size(214, 24)
        Me.AddNewStockToolStripMenuItem.Text = "Add New Cloth"
        '
        'ViewStockListToolStripMenuItem
        '
        Me.ViewStockListToolStripMenuItem.Name = "ViewStockListToolStripMenuItem"
        Me.ViewStockListToolStripMenuItem.Size = New System.Drawing.Size(214, 24)
        Me.ViewStockListToolStripMenuItem.Text = "View Cloth List"
        '
        'TransectionsToolStripMenuItem
        '
        Me.TransectionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PurchaseEntryToolStripMenuItem, Me.SalesEntryToolStripMenuItem})
        Me.TransectionsToolStripMenuItem.Name = "TransectionsToolStripMenuItem"
        Me.TransectionsToolStripMenuItem.Size = New System.Drawing.Size(146, 24)
        Me.TransectionsToolStripMenuItem.Text = "Purchase and Sales"
        '
        'PurchaseEntryToolStripMenuItem
        '
        Me.PurchaseEntryToolStripMenuItem.Name = "PurchaseEntryToolStripMenuItem"
        Me.PurchaseEntryToolStripMenuItem.Size = New System.Drawing.Size(205, 24)
        Me.PurchaseEntryToolStripMenuItem.Text = "Add Purchase Entry"
        '
        'SalesEntryToolStripMenuItem
        '
        Me.SalesEntryToolStripMenuItem.Name = "SalesEntryToolStripMenuItem"
        Me.SalesEntryToolStripMenuItem.Size = New System.Drawing.Size(205, 24)
        Me.SalesEntryToolStripMenuItem.Text = "Sales & Bill"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StcokReportToolStripMenuItem, Me.PurchaseReportToolStripMenuItem, Me.SalesReportToolStripMenuItem, Me.EmployeeReportToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(72, 24)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'StcokReportToolStripMenuItem
        '
        Me.StcokReportToolStripMenuItem.Name = "StcokReportToolStripMenuItem"
        Me.StcokReportToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.StcokReportToolStripMenuItem.Text = "Stcok Report"
        '
        'PurchaseReportToolStripMenuItem
        '
        Me.PurchaseReportToolStripMenuItem.Name = "PurchaseReportToolStripMenuItem"
        Me.PurchaseReportToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.PurchaseReportToolStripMenuItem.Text = "Purchase Report"
        '
        'SalesReportToolStripMenuItem
        '
        Me.SalesReportToolStripMenuItem.Name = "SalesReportToolStripMenuItem"
        Me.SalesReportToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.SalesReportToolStripMenuItem.Text = "Sales Report"
        '
        'EmployeeReportToolStripMenuItem
        '
        Me.EmployeeReportToolStripMenuItem.Name = "EmployeeReportToolStripMenuItem"
        Me.EmployeeReportToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.EmployeeReportToolStripMenuItem.Text = "Employee Report"
        '
        'UserToolStripMenuItem
        '
        Me.UserToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.AddNewUserToolStripMenuItem, Me.RemoveUserToolStripMenuItem, Me.ShowUsersToolStripMenuItem})
        Me.UserToolStripMenuItem.Name = "UserToolStripMenuItem"
        Me.UserToolStripMenuItem.Size = New System.Drawing.Size(58, 24)
        Me.UserToolStripMenuItem.Text = "Login"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(213, 24)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'AddNewUserToolStripMenuItem
        '
        Me.AddNewUserToolStripMenuItem.Name = "AddNewUserToolStripMenuItem"
        Me.AddNewUserToolStripMenuItem.Size = New System.Drawing.Size(213, 24)
        Me.AddNewUserToolStripMenuItem.Text = "Add Login Details"
        '
        'RemoveUserToolStripMenuItem
        '
        Me.RemoveUserToolStripMenuItem.Name = "RemoveUserToolStripMenuItem"
        Me.RemoveUserToolStripMenuItem.Size = New System.Drawing.Size(213, 24)
        Me.RemoveUserToolStripMenuItem.Text = "Delete Login Details"
        '
        'ShowUsersToolStripMenuItem
        '
        Me.ShowUsersToolStripMenuItem.Name = "ShowUsersToolStripMenuItem"
        Me.ShowUsersToolStripMenuItem.Size = New System.Drawing.Size(213, 24)
        Me.ShowUsersToolStripMenuItem.Text = "Show All Users"
        '
        'ApplicatiionToolStripMenuItem
        '
        Me.ApplicatiionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.ApplicatiionToolStripMenuItem.Name = "ApplicatiionToolStripMenuItem"
        Me.ApplicatiionToolStripMenuItem.Size = New System.Drawing.Size(98, 24)
        Me.ApplicatiionToolStripMenuItem.Text = "Application"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(102, 24)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Mdimain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(985, 535)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Mdimain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "MDI"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicatiionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveUserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowUsersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransectionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewCategoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewStockListToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewEmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditEmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteEmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewEmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StcokReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
